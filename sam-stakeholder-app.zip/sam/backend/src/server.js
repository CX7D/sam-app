const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

// In-memory store
let projects = {};
let stakeholders = {};
let relationships = {};

// ── Projects ──────────────────────────────────────────────────
app.get('/api/projects', (req, res) => {
  res.json(Object.values(projects));
});

app.post('/api/projects', (req, res) => {
  const id = uuidv4();
  const project = { id, createdAt: new Date().toISOString(), ...req.body };
  projects[id] = project;
  res.status(201).json(project);
});

app.put('/api/projects/:id', (req, res) => {
  if (!projects[req.params.id]) return res.status(404).json({ error: 'Not found' });
  projects[req.params.id] = { ...projects[req.params.id], ...req.body };
  res.json(projects[req.params.id]);
});

app.delete('/api/projects/:id', (req, res) => {
  delete projects[req.params.id];
  // Cascade delete stakeholders
  Object.keys(stakeholders).forEach(k => {
    if (stakeholders[k].projectId === req.params.id) {
      delete stakeholders[k];
      delete relationships[k];
    }
  });
  res.json({ ok: true });
});

// ── Stakeholders ──────────────────────────────────────────────
app.get('/api/projects/:projectId/stakeholders', (req, res) => {
  const list = Object.values(stakeholders).filter(s => s.projectId === req.params.projectId);
  res.json(list);
});

app.post('/api/projects/:projectId/stakeholders', (req, res) => {
  const id = uuidv4();
  const s = { id, projectId: req.params.projectId, createdAt: new Date().toISOString(), ...req.body };
  stakeholders[id] = s;
  res.status(201).json(s);
});

app.put('/api/stakeholders/:id', (req, res) => {
  if (!stakeholders[req.params.id]) return res.status(404).json({ error: 'Not found' });
  stakeholders[req.params.id] = { ...stakeholders[req.params.id], ...req.body };
  res.json(stakeholders[req.params.id]);
});

app.delete('/api/stakeholders/:id', (req, res) => {
  delete stakeholders[req.params.id];
  // Remove relationships involving this stakeholder
  Object.keys(relationships).forEach(k => {
    relationships[k] = relationships[k].filter(
      r => r.sourceId !== req.params.id && r.targetId !== req.params.id
    );
  });
  res.json({ ok: true });
});

// ── Relationships ─────────────────────────────────────────────
app.get('/api/projects/:projectId/relationships', (req, res) => {
  res.json(relationships[req.params.projectId] || []);
});

app.post('/api/projects/:projectId/relationships', (req, res) => {
  if (!relationships[req.params.projectId]) relationships[req.params.projectId] = [];
  const rel = { id: uuidv4(), ...req.body };
  relationships[req.params.projectId].push(rel);
  res.status(201).json(rel);
});

app.delete('/api/projects/:projectId/relationships/:relId', (req, res) => {
  if (!relationships[req.params.projectId]) return res.json({ ok: true });
  relationships[req.params.projectId] = relationships[req.params.projectId].filter(
    r => r.id !== req.params.relId
  );
  res.json({ ok: true });
});

// ── Health ────────────────────────────────────────────────────
app.get('/health', (_, res) => res.json({ status: 'ok' }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`SAM API running on :${PORT}`));
