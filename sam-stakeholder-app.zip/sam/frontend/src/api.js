const BASE = '/api';

async function req(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export const api = {
  // Projects
  getProjects: () => req('GET', '/projects'),
  createProject: d => req('POST', '/projects', d),
  updateProject: (id, d) => req('PUT', `/projects/${id}`, d),
  deleteProject: id => req('DELETE', `/projects/${id}`),
  // Stakeholders
  getStakeholders: pid => req('GET', `/projects/${pid}/stakeholders`),
  createStakeholder: (pid, d) => req('POST', `/projects/${pid}/stakeholders`, d),
  updateStakeholder: (id, d) => req('PUT', `/stakeholders/${id}`, d),
  deleteStakeholder: id => req('DELETE', `/stakeholders/${id}`),
  // Relationships
  getRelationships: pid => req('GET', `/projects/${pid}/relationships`),
  createRelationship: (pid, d) => req('POST', `/projects/${pid}/relationships`, d),
  deleteRelationship: (pid, rid) => req('DELETE', `/projects/${pid}/relationships/${rid}`)
};
