import React, { useState, useEffect, useCallback } from 'react';
import { api } from './api.js';
import { SUPPORT_MAP, SUPPORT_OPTIONS, REL_TYPES } from './constants.js';
import Matrix from './components/Matrix.jsx';
import Network from './components/Network.jsx';
import StakeholderModal from './components/StakeholderModal.jsx';
import RelationshipModal from './components/RelationshipModal.jsx';
import ProjectModal from './components/ProjectModal.jsx';
import StakeholderDetail from './components/StakeholderDetail.jsx';

// ── Icons (inline SVG) ──────────────────────────────────────
const Icon = ({ d, size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d={d}/>
  </svg>
);
const IPlus       = () => <Icon d="M12 5v14M5 12h14"/>;
const IProject    = () => <Icon d="M3 3h18v4H3zM3 10h18v11H3z"/>;
const INetwork    = () => <Icon d="M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0zM12 7V3M12 21v-4M7 12H3M21 12h-4"/>;
const IMatrix     = () => <Icon d="M3 3v18h18M9 9h6v6H9z"/>;
const IList       = () => <Icon d="M8 6h13M8 12h13M8 18h13M3 6h1v1H3zM3 12h1v1H3zM3 18h1v1H3z"/>;
const ITrash      = () => <Icon d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>;
const IEdit       = () => <Icon d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>;
const ILink       = () => <Icon d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>;

const VIEWS = ['matrix', 'network', 'list'];

export default function App() {
  const [projects, setProjects]         = useState([]);
  const [currentProject, setCurrentProject] = useState(null);
  const [stakeholders, setStakeholders] = useState([]);
  const [relationships, setRelationships] = useState([]);
  const [view, setView]                 = useState('matrix');
  const [selected, setSelected]         = useState(null);
  const [loading, setLoading]           = useState(true);
  const [error, setError]               = useState(null);

  // Modals
  const [showProjectModal, setShowProjectModal]       = useState(false);
  const [showStakeholderModal, setShowStakeholderModal] = useState(false);
  const [showRelModal, setShowRelModal]               = useState(false);
  const [editingStakeholder, setEditingStakeholder]   = useState(null);
  const [editingProject, setEditingProject]           = useState(null);

  // Load projects
  useEffect(() => {
    api.getProjects()
      .then(p => {
        setProjects(p);
        if (p.length) setCurrentProject(p[0]);
        setLoading(false);
      })
      .catch(err => { setError(err.message); setLoading(false); });
  }, []);

  // Load stakeholders & relationships when project changes
  useEffect(() => {
    if (!currentProject) { setStakeholders([]); setRelationships([]); return; }
    Promise.all([
      api.getStakeholders(currentProject.id),
      api.getRelationships(currentProject.id)
    ]).then(([s, r]) => { setStakeholders(s); setRelationships(r); setSelected(null); });
  }, [currentProject]);

  // ── Project CRUD ──────────────────────────────────────────
  const createProject = async (data) => {
    const p = await api.createProject(data);
    setProjects(prev => [...prev, p]);
    setCurrentProject(p);
    setShowProjectModal(false);
  };
  const updateProject = async (data) => {
    const p = await api.updateProject(editingProject.id, data);
    setProjects(prev => prev.map(x => x.id === p.id ? p : x));
    if (currentProject?.id === p.id) setCurrentProject(p);
    setEditingProject(null);
    setShowProjectModal(false);
  };
  const deleteProject = async (id) => {
    if (!confirm('Delete this project and all its stakeholders?')) return;
    await api.deleteProject(id);
    setProjects(prev => {
      const next = prev.filter(p => p.id !== id);
      setCurrentProject(next[0] || null);
      return next;
    });
  };

  // ── Stakeholder CRUD ──────────────────────────────────────
  const createStakeholder = async (data) => {
    const s = await api.createStakeholder(currentProject.id, data);
    setStakeholders(prev => [...prev, s]);
    setShowStakeholderModal(false);
  };
  const updateStakeholder = async (data) => {
    const s = await api.updateStakeholder(editingStakeholder.id, data);
    setStakeholders(prev => prev.map(x => x.id === s.id ? s : x));
    if (selected?.id === s.id) setSelected(s);
    setEditingStakeholder(null);
    setShowStakeholderModal(false);
  };
  const deleteStakeholder = async (id) => {
    if (!confirm('Delete this stakeholder?')) return;
    await api.deleteStakeholder(id);
    setStakeholders(prev => prev.filter(s => s.id !== id));
    setRelationships(prev => prev.filter(r => r.sourceId !== id && r.targetId !== id));
    if (selected?.id === id) setSelected(null);
  };

  // ── Relationship CRUD ─────────────────────────────────────
  const createRelationship = async (data) => {
    const r = await api.createRelationship(currentProject.id, data);
    setRelationships(prev => [...prev, r]);
    setShowRelModal(false);
  };
  const deleteRelationship = async (id) => {
    await api.deleteRelationship(currentProject.id, id);
    setRelationships(prev => prev.filter(r => r.id !== id));
  };

  // ── Helpers ───────────────────────────────────────────────
  const openEditStakeholder = (s) => { setEditingStakeholder(s); setShowStakeholderModal(true); };
  const openNewStakeholder  = () => { setEditingStakeholder(null); setShowStakeholderModal(true); };
  const openEditProject     = (p) => { setEditingProject(p); setShowProjectModal(true); };
  const openNewProject      = () => { setEditingProject(null); setShowProjectModal(true); };

  const stakeholderName = id => stakeholders.find(s => s.id === id)?.name || id;
  const relTypeName = t => REL_TYPES.find(r => r.value === t)?.label || t;

  if (loading) return (
    <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ fontFamily: 'var(--font-mono)', color: 'var(--muted)', fontSize: 13 }}>
        Connecting to S.A.M…
      </div>
    </div>
  );

  if (error) return (
    <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 12 }}>
      <div style={{ color: 'var(--accent3)', fontWeight: 700 }}>API Error</div>
      <div style={{ color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>{error}</div>
    </div>
  );

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* ── TOP BAR ─────────────────────────────────────── */}
      <header style={{
        display: 'flex', alignItems: 'center', gap: 16,
        padding: '0 20px',
        height: 52,
        borderBottom: '1px solid var(--border)',
        background: 'var(--surface)',
        flexShrink: 0
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginRight: 4 }}>
          <span style={{ fontWeight: 800, fontSize: 18, letterSpacing: '.12em', color: 'var(--accent)' }}>S.A.M.</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--muted)' }}>stakeholder analysis</span>
        </div>

        {/* Project selector */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0 }}>
          <select
            value={currentProject?.id || ''}
            onChange={e => setCurrentProject(projects.find(p => p.id === e.target.value) || null)}
            style={{ maxWidth: 280, fontSize: 13 }}
          >
            <option value="" disabled>— Select project —</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          {currentProject && (
            <button className="btn-icon" title="Edit project" onClick={() => openEditProject(currentProject)}>
              <IEdit/>
            </button>
          )}
          {currentProject && (
            <button className="btn-icon" title="Delete project" onClick={() => deleteProject(currentProject.id)}
              style={{ color: 'var(--accent3)' }}>
              <ITrash/>
            </button>
          )}
          <button className="btn btn-ghost btn-sm" onClick={openNewProject}><IPlus/> Project</button>
        </div>

        {/* View tabs */}
        <div style={{ display: 'flex', gap: 2, background: 'var(--bg)', borderRadius: 6, padding: 3 }}>
          {[
            { id: 'matrix',  icon: <IMatrix/>,  tip: 'Power/Interest Matrix' },
            { id: 'network', icon: <INetwork/>, tip: 'Relationship Network' },
            { id: 'list',    icon: <IList/>,    tip: 'Stakeholder List' }
          ].map(v => (
            <button key={v.id} title={v.tip}
              onClick={() => setView(v.id)}
              style={{
                padding: '5px 12px', borderRadius: 4, display: 'flex', alignItems: 'center', gap: 5,
                fontSize: 11, fontWeight: 700, letterSpacing: '.06em', textTransform: 'uppercase',
                color: view === v.id ? 'var(--bg)' : 'var(--muted)',
                background: view === v.id ? 'var(--accent)' : 'transparent',
                transition: 'all .15s'
              }}>
              {v.icon}
              {v.id}
            </button>
          ))}
        </div>

        {/* Actions */}
        {currentProject && <>
          <button className="btn btn-primary btn-sm" onClick={openNewStakeholder}><IPlus/> Stakeholder</button>
          {view === 'network' && stakeholders.length >= 2 &&
            <button className="btn btn-ghost btn-sm" onClick={() => setShowRelModal(true)}><ILink/> Relation</button>}
        </>}
      </header>

      {/* ── MAIN AREA ────────────────────────────────────── */}
      <main style={{ flex: 1, overflow: 'hidden', display: 'flex' }}>
        {!currentProject ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, color: 'var(--muted)' }}>
            <div style={{ fontSize: 48, opacity: .2 }}>◈</div>
            <div style={{ fontWeight: 700, fontSize: 16, letterSpacing: '.06em', textTransform: 'uppercase' }}>No Project Selected</div>
            <p style={{ fontSize: 13, maxWidth: 320, textAlign: 'center', lineHeight: 1.6 }}>Create a project to start mapping your stakeholders and their relationships.</p>
            <button className="btn btn-primary" onClick={openNewProject}><IPlus/> Create First Project</button>
          </div>
        ) : (
          <div style={{ flex: 1, overflow: 'hidden', display: 'flex' }}>
            {/* Content */}
            <div style={{ flex: 1, overflow: 'auto', padding: 20 }}>
              {view === 'matrix' && (
                <div>
                  <SectionHeader title="Power / Interest Matrix"
                    sub={`${stakeholders.length} stakeholder${stakeholders.length !== 1 ? 's' : ''}`}/>
                  {stakeholders.length === 0
                    ? <EmptyState msg="Add stakeholders to see them on the matrix" onAdd={openNewStakeholder}/>
                    : <div style={{ maxWidth: 700, margin: '0 auto' }}>
                        <Matrix stakeholders={stakeholders} onSelect={setSelected} selectedId={selected?.id}/>
                        <Legend/>
                      </div>}
                </div>
              )}

              {view === 'network' && (
                <div>
                  <SectionHeader title="Relationship Network"
                    sub={`${relationships.length} relationship${relationships.length !== 1 ? 's' : ''}`}/>
                  <div style={{ maxWidth: 740, margin: '0 auto' }}>
                    <Network stakeholders={stakeholders} relationships={relationships}
                      onSelectStakeholder={setSelected} selectedId={selected?.id}/>
                    {/* Relationship list */}
                    {relationships.length > 0 && (
                      <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
                        <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted)', letterSpacing: '.06em', textTransform: 'uppercase' }}>Connections</span>
                        {relationships.map(r => (
                          <div key={r.id} className="card" style={{ padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
                            <span style={{ fontSize: 12, fontWeight: 600 }}>{stakeholderName(r.sourceId)}</span>
                            <span style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>—{relTypeName(r.type)}→</span>
                            <span style={{ fontSize: 12, fontWeight: 600 }}>{stakeholderName(r.targetId)}</span>
                            {r.label && <span style={{ fontSize: 11, color: 'var(--muted)', flex: 1, textAlign: 'right', fontStyle: 'italic' }}>{r.label}</span>}
                            <button className="btn-icon btn-sm" style={{ color: 'var(--accent3)' }}
                              onClick={() => deleteRelationship(r.id)}>✕</button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {view === 'list' && (
                <div>
                  <SectionHeader title="Stakeholders" sub={`${stakeholders.length} total`}/>
                  {stakeholders.length === 0
                    ? <EmptyState msg="No stakeholders yet" onAdd={openNewStakeholder}/>
                    : <StakeholderTable stakeholders={stakeholders}
                        onSelect={s => { setSelected(s); }}
                        onEdit={openEditStakeholder}
                        onDelete={deleteStakeholder}
                        selectedId={selected?.id}/>}
                </div>
              )}
            </div>

            {/* Detail panel */}
            {selected && (
              <aside style={{ width: 300, borderLeft: '1px solid var(--border)', padding: 16, overflow: 'auto', flexShrink: 0 }}>
                <StakeholderDetail
                  stakeholder={selected}
                  onEdit={() => openEditStakeholder(selected)}
                  onDelete={() => deleteStakeholder(selected.id)}
                  onClose={() => setSelected(null)}/>
              </aside>
            )}
          </div>
        )}
      </main>

      {/* ── MODALS ───────────────────────────────────────── */}
      {showProjectModal && (
        <ProjectModal
          initial={editingProject}
          onSave={editingProject ? updateProject : createProject}
          onClose={() => { setShowProjectModal(false); setEditingProject(null); }}/>
      )}
      {showStakeholderModal && (
        <StakeholderModal
          initial={editingStakeholder}
          onSave={editingStakeholder ? updateStakeholder : createStakeholder}
          onClose={() => { setShowStakeholderModal(false); setEditingStakeholder(null); }}/>
      )}
      {showRelModal && (
        <RelationshipModal
          stakeholders={stakeholders}
          onSave={createRelationship}
          onClose={() => setShowRelModal(false)}/>
      )}
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────
function SectionHeader({ title, sub }) {
  return (
    <div style={{ marginBottom: 16, display: 'flex', alignItems: 'baseline', gap: 10 }}>
      <h2 style={{ fontWeight: 800, fontSize: 16, letterSpacing: '.04em', textTransform: 'uppercase' }}>{title}</h2>
      {sub && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>{sub}</span>}
    </div>
  );
}

function EmptyState({ msg, onAdd }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, padding: '60px 20px', color: 'var(--muted)' }}>
      <div style={{ fontSize: 36, opacity: .2 }}>◈</div>
      <p style={{ fontSize: 13 }}>{msg}</p>
      <button className="btn btn-primary btn-sm" onClick={onAdd}>+ Add Stakeholder</button>
    </div>
  );
}

function Legend() {
  return (
    <div style={{ marginTop: 12, display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
      {SUPPORT_OPTIONS.map(s => (
        <div key={s.value} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: s.color }}/>
          <span style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{s.label}</span>
        </div>
      ))}
    </div>
  );
}

function StakeholderTable({ stakeholders, onSelect, onEdit, onDelete, selectedId }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {/* Header row */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 160px 100px 80px 80px 90px 80px',
        padding: '6px 14px', gap: 10,
        fontSize: 10, fontWeight: 600, color: 'var(--muted)',
        textTransform: 'uppercase', letterSpacing: '.06em'
      }}>
        <span>Name / Role</span>
        <span>Category</span>
        <span>Stance</span>
        <span style={{ textAlign: 'center' }}>Interest</span>
        <span style={{ textAlign: 'center' }}>Influence</span>
        <span>Organization</span>
        <span></span>
      </div>
      {stakeholders.map(s => {
        const support = SUPPORT_MAP[s.support] || SUPPORT_MAP['neutral'];
        const isSelected = s.id === selectedId;
        return (
          <div key={s.id}
            className="card"
            onClick={() => onSelect(s)}
            style={{
              display: 'grid', gridTemplateColumns: '1fr 160px 100px 80px 80px 90px 80px',
              alignItems: 'center', padding: '10px 14px', gap: 10, cursor: 'pointer',
              borderColor: isSelected ? 'var(--accent)' : undefined
            }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <span style={{ fontWeight: 700, fontSize: 13 }}>{s.name}</span>
              {s.role && <span style={{ fontSize: 11, color: 'var(--muted)' }}>{s.role}</span>}
            </div>
            <span style={{ fontSize: 11, color: 'var(--muted)' }}>{s.category}</span>
            <span className="tag" style={{ background: support.color + '22', color: support.color, fontSize: 9 }}>{support.label}</span>
            <div style={{ textAlign: 'center' }}>
              <MiniBar value={s.interest} color="var(--accent2)"/>
            </div>
            <div style={{ textAlign: 'center' }}>
              <MiniBar value={s.influence} color="var(--accent)"/>
            </div>
            <span style={{ fontSize: 11, color: 'var(--muted)' }}>{s.organization || '—'}</span>
            <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
              <button className="btn-icon" style={{ fontSize: 12 }}
                onClick={e => { e.stopPropagation(); onEdit(s); }}>✎</button>
              <button className="btn-icon" style={{ fontSize: 12, color: 'var(--accent3)' }}
                onClick={e => { e.stopPropagation(); onDelete(s.id); }}>✕</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function MiniBar({ value, color }) {
  return (
    <div style={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
      {[1,2,3,4,5].map(i => (
        <div key={i} style={{ width: 8, height: 8, borderRadius: 2, background: i <= value ? color : 'var(--border)' }}/>
      ))}
    </div>
  );
}
