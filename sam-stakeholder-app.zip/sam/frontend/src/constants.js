export const INTEREST_LABELS = ['Minimal','Low','Moderate','High','Critical'];
export const INFLUENCE_LABELS = ['Minimal','Low','Moderate','High','Critical'];
export const SUPPORT_OPTIONS = [
  { value: 'champion',  label: 'Champion',  color: '#4af0b0' },
  { value: 'supporter', label: 'Supporter', color: '#60c0f0' },
  { value: 'neutral',   label: 'Neutral',   color: '#8090a0' },
  { value: 'skeptic',   label: 'Skeptic',   color: '#f0c040' },
  { value: 'blocker',   label: 'Blocker',   color: '#f04060' }
];
export const CATEGORY_OPTIONS = [
  'Internal','External','Government','Customer','Supplier','Partner','Community','Media','Investor','Other'
];
export const REL_TYPES = [
  { value: 'reports_to',    label: 'Reports To' },
  { value: 'influences',    label: 'Influences' },
  { value: 'collaborates',  label: 'Collaborates' },
  { value: 'opposes',       label: 'Opposes' },
  { value: 'funds',         label: 'Funds' },
  { value: 'approves',      label: 'Approves' }
];
export const SUPPORT_MAP = Object.fromEntries(SUPPORT_OPTIONS.map(s => [s.value, s]));
