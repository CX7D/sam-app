import React, { useState, useRef } from 'react';
import { SUPPORT_MAP } from '../constants.js';

const QUADRANTS = [
  { x: 0, y: 0, w: .5, h: .5, label: 'Monitor', sub: 'Low Power · Low Interest', fill: '#1a1e25' },
  { x: .5, y: 0, w: .5, h: .5, label: 'Keep Informed', sub: 'Low Power · High Interest', fill: '#1c2020' },
  { x: 0, y: .5, w: .5, h: .5, label: 'Keep Satisfied', sub: 'High Power · Low Interest', fill: '#1c1a20' },
  { x: .5, y: .5, w: .5, h: .5, label: 'Manage Closely', sub: 'High Power · High Interest', fill: '#1f1c14' }
];

export default function Matrix({ stakeholders, onSelect, selectedId }) {
  const svgRef = useRef(null);
  const [hover, setHover] = useState(null);
  const W = 640, H = 480, PAD = 48;
  const iW = W - PAD * 2, iH = H - PAD * 2;

  const pos = (s) => ({
    cx: PAD + ((s.interest - 1) / 4) * iW,
    cy: PAD + iH - ((s.influence - 1) / 4) * iH
  });

  return (
    <div style={{ width: '100%', aspectRatio: '4/3', position: 'relative' }}>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${W} ${H}`}
        style={{ width: '100%', height: '100%', display: 'block' }}
      >
        <defs>
          <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
            <path d="M 32 0 L 0 0 0 32" fill="none" stroke="#2a2f3a" strokeWidth=".5"/>
          </pattern>
        </defs>

        {/* Quadrant backgrounds */}
        {QUADRANTS.map((q, i) => (
          <rect
            key={i}
            x={PAD + q.x * iW} y={PAD + (1 - q.y - q.h) * iH}
            width={q.w * iW} height={q.h * iH}
            fill={q.fill} stroke="#2a2f3a" strokeWidth="1"
          />
        ))}

        {/* Grid overlay */}
        <rect x={PAD} y={PAD} width={iW} height={iH} fill="url(#grid)" opacity=".4"/>

        {/* Quadrant labels */}
        {QUADRANTS.map((q, i) => {
          const rx = PAD + q.x * iW + q.w * iW / 2;
          const ry = PAD + (1 - q.y - q.h) * iH + q.h * iH / 2;
          return (
            <g key={i} opacity=".35">
              <text x={rx} y={ry - 8} textAnchor="middle" fill="#e8eaf0" fontSize="12" fontWeight="700" fontFamily="Syne, sans-serif" letterSpacing="2">{q.label.toUpperCase()}</text>
              <text x={rx} y={ry + 10} textAnchor="middle" fill="#6b7385" fontSize="9" fontFamily="DM Mono, monospace">{q.sub}</text>
            </g>
          );
        })}

        {/* Axes */}
        <line x1={PAD} y1={PAD} x2={PAD} y2={PAD + iH} stroke="#6b7385" strokeWidth="1.5"/>
        <line x1={PAD} y1={PAD + iH} x2={PAD + iW} y2={PAD + iH} stroke="#6b7385" strokeWidth="1.5"/>

        {/* Axis labels */}
        <text x={PAD + iW / 2} y={H - 8} textAnchor="middle" fill="#6b7385" fontSize="10" fontFamily="Syne, sans-serif" letterSpacing="3">INTEREST / IMPACT →</text>
        <text x={14} y={PAD + iH / 2} textAnchor="middle" fill="#6b7385" fontSize="10" fontFamily="Syne, sans-serif" letterSpacing="3" transform={`rotate(-90, 14, ${PAD + iH / 2})`}>INFLUENCE / POWER →</text>

        {/* Tick marks */}
        {[1,2,3,4,5].map(v => {
          const x = PAD + ((v-1)/4) * iW;
          const y = PAD + iH - ((v-1)/4) * iH;
          return (
            <g key={v}>
              <line x1={x} y1={PAD+iH} x2={x} y2={PAD+iH+4} stroke="#6b7385" strokeWidth="1"/>
              <line x1={PAD-4} y1={y} x2={PAD} y2={y} stroke="#6b7385" strokeWidth="1"/>
              <text x={x} y={PAD+iH+14} textAnchor="middle" fill="#6b7385" fontSize="8" fontFamily="DM Mono, monospace">{v}</text>
              <text x={PAD-8} y={y+3} textAnchor="end" fill="#6b7385" fontSize="8" fontFamily="DM Mono, monospace">{v}</text>
            </g>
          );
        })}

        {/* Stakeholder nodes */}
        {stakeholders.map(s => {
          const { cx, cy } = pos(s);
          const support = SUPPORT_MAP[s.support] || SUPPORT_MAP['neutral'];
          const r = 8 + ((s.influence + s.interest) / 10) * 6;
          const isSelected = s.id === selectedId;
          const isHovered = s.id === hover;
          return (
            <g key={s.id}
               style={{ cursor: 'pointer' }}
               onClick={() => onSelect(s)}
               onMouseEnter={() => setHover(s.id)}
               onMouseLeave={() => setHover(null)}>
              {/* Glow */}
              {(isSelected || isHovered) && (
                <circle cx={cx} cy={cy} r={r + 8} fill={support.color} opacity=".15"/>
              )}
              <circle
                cx={cx} cy={cy} r={r}
                fill={support.color}
                fillOpacity={isSelected ? 1 : .75}
                stroke={isSelected ? '#fff' : support.color}
                strokeWidth={isSelected ? 2.5 : 1}
              />
              <text x={cx} y={cy + 3.5} textAnchor="middle" fill="#0d0f12" fontSize="9" fontWeight="700" fontFamily="Syne, sans-serif">
                {s.name.slice(0,3).toUpperCase()}
              </text>
              {/* Name label */}
              <text x={cx} y={cy - r - 5} textAnchor="middle" fill="#e8eaf0" fontSize="9" fontFamily="Syne, sans-serif"
                opacity={(isSelected || isHovered) ? 1 : 0.7}>
                {s.name.length > 14 ? s.name.slice(0,13)+'…' : s.name}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
