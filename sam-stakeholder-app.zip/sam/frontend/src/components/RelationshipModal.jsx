import React, { useState } from 'react';
import { REL_TYPES } from '../constants.js';

export default function RelationshipModal({ stakeholders, onSave, onClose }) {
  const [sourceId, setSourceId] = useState('');
  const [targetId, setTargetId] = useState('');
  const [type, setType] = useState('influences');
  const [label, setLabel] = useState('');

  const valid = sourceId && targetId && sourceId !== targetId;

  return (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <span style={{ fontWeight: 700, fontSize: 15, letterSpacing: '.04em' }}>Add Relationship</span>
          <button className="btn-icon" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div className="flex col gap1">
            <label>From (Source)</label>
            <select value={sourceId} onChange={e => setSourceId(e.target.value)}>
              <option value="">— select stakeholder —</option>
              {stakeholders.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="flex col gap1">
            <label>Relationship Type</label>
            <select value={type} onChange={e => setType(e.target.value)}>
              {REL_TYPES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
          <div className="flex col gap1">
            <label>To (Target)</label>
            <select value={targetId} onChange={e => setTargetId(e.target.value)}>
              <option value="">— select stakeholder —</option>
              {stakeholders.filter(s => s.id !== sourceId).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="flex col gap1">
            <label>Note (optional)</label>
            <input value={label} onChange={e => setLabel(e.target.value)} placeholder="e.g. Weekly sync"/>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={!valid}
            onClick={() => onSave({ sourceId, targetId, type, label })}>
            Add Relationship
          </button>
        </div>
      </div>
    </div>
  );
}
