import React from 'react';
import { SUPPORT_MAP, INTEREST_LABELS, INFLUENCE_LABELS } from '../constants.js';

export default function StakeholderDetail({ stakeholder, onEdit, onDelete, onClose }) {
  const s = stakeholder;
  const support = SUPPORT_MAP[s.support] || SUPPORT_MAP['neutral'];

  return (
    <div style={{
      background: 'var(--panel)',
      border: '1px solid var(--border2)',
      borderRadius: '6px',
      display: 'flex', flexDirection: 'column', gap: 0,
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{
        padding: '16px 18px',
        borderBottom: '1px solid var(--border)',
        background: support.color + '14'
      }}>
        <div className="flex align-center justify-between">
          <div className="flex col gap1">
            <span style={{ fontWeight: 800, fontSize: 16, letterSpacing: '.02em' }}>{s.name}</span>
            {s.role && <span style={{ color: 'var(--muted)', fontSize: 12 }}>{s.role}{s.organization ? ` · ${s.organization}` : ''}</span>}
          </div>
          <button className="btn-icon" onClick={onClose}>✕</button>
        </div>
        <div className="flex gap2" style={{ marginTop: 10, flexWrap: 'wrap' }}>
          <span className="tag" style={{ background: support.color + '22', color: support.color }}>{support.label}</span>
          <span className="tag" style={{ background: 'var(--border)', color: 'var(--muted)' }}>{s.category}</span>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* Score bars */}
        <div className="flex col gap2">
          <ScoreBar label="Interest" value={s.interest} valueLabel={INTEREST_LABELS[s.interest - 1]} color="var(--accent2)"/>
          <ScoreBar label="Influence" value={s.influence} valueLabel={INFLUENCE_LABELS[s.influence - 1]} color="var(--accent)"/>
        </div>

        {s.email && (
          <div className="flex col gap1">
            <span style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.06em', fontWeight: 600 }}>Email</span>
            <a href={`mailto:${s.email}`} style={{ color: 'var(--accent)', fontSize: 12, fontFamily: 'var(--font-mono)', textDecoration: 'none' }}>{s.email}</a>
          </div>
        )}

        {s.notes && (
          <div className="flex col gap1">
            <span style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.06em', fontWeight: 600 }}>Notes</span>
            <p style={{ fontSize: 12, color: 'var(--text)', lineHeight: 1.6, background: 'var(--surface)', borderRadius: 4, padding: '10px 12px', border: '1px solid var(--border)' }}>{s.notes}</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{ padding: '12px 18px', borderTop: '1px solid var(--border)', display: 'flex', gap: 8 }}>
        <button className="btn btn-ghost btn-sm grow" onClick={onEdit}>Edit</button>
        <button className="btn btn-danger btn-sm" onClick={onDelete}>Delete</button>
      </div>
    </div>
  );
}

function ScoreBar({ label, value, valueLabel, color }) {
  return (
    <div>
      <div className="flex justify-between" style={{ marginBottom: 4 }}>
        <span style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.06em', fontWeight: 600 }}>{label}</span>
        <span style={{ fontSize: 10, color, fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{valueLabel} ({value}/5)</span>
      </div>
      <div style={{ height: 5, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ height: '100%', width: `${(value / 5) * 100}%`, background: color, borderRadius: 3, transition: 'width .3s ease' }}/>
      </div>
    </div>
  );
}
