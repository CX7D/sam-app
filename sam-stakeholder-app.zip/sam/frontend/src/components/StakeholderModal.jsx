import React, { useState, useEffect } from 'react';
import { SUPPORT_OPTIONS, CATEGORY_OPTIONS, INTEREST_LABELS, INFLUENCE_LABELS } from '../constants.js';

const EMPTY = {
  name: '', role: '', organization: '', category: 'Internal',
  interest: 3, influence: 3, support: 'neutral', notes: '', email: ''
};

export default function StakeholderModal({ initial, onSave, onClose }) {
  const [form, setForm] = useState(initial ? { ...initial } : { ...EMPTY });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = () => {
    if (!form.name.trim()) return;
    onSave(form);
  };

  return (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <span style={{ fontWeight: 700, fontSize: 15, letterSpacing: '.04em' }}>
            {initial ? 'Edit Stakeholder' : 'New Stakeholder'}
          </span>
          <button className="btn-icon" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div className="flex gap3" style={{ flexWrap: 'wrap' }}>
            <div className="flex col gap1 grow">
              <label>Name *</label>
              <input value={form.name} onChange={e => set('name', e.target.value)} placeholder="Full name"/>
            </div>
            <div className="flex col gap1 grow">
              <label>Role / Title</label>
              <input value={form.role} onChange={e => set('role', e.target.value)} placeholder="e.g. CFO"/>
            </div>
          </div>
          <div className="flex gap3" style={{ flexWrap: 'wrap' }}>
            <div className="flex col gap1 grow">
              <label>Organization</label>
              <input value={form.organization} onChange={e => set('organization', e.target.value)} placeholder="Company / dept"/>
            </div>
            <div className="flex col gap1 grow">
              <label>Email</label>
              <input value={form.email} onChange={e => set('email', e.target.value)} placeholder="optional"/>
            </div>
          </div>
          <div className="flex gap3" style={{ flexWrap: 'wrap' }}>
            <div className="flex col gap1 grow">
              <label>Category</label>
              <select value={form.category} onChange={e => set('category', e.target.value)}>
                {CATEGORY_OPTIONS.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="flex col gap1 grow">
              <label>Stance / Support</label>
              <select value={form.support} onChange={e => set('support', e.target.value)}>
                {SUPPORT_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
          </div>
          <div className="flex col gap1">
            <label>Interest Level — {INTEREST_LABELS[form.interest - 1]} ({form.interest}/5)</label>
            <input type="range" min="1" max="5" value={form.interest}
              onChange={e => set('interest', +e.target.value)}/>
          </div>
          <div className="flex col gap1">
            <label>Influence / Power — {INFLUENCE_LABELS[form.influence - 1]} ({form.influence}/5)</label>
            <input type="range" min="1" max="5" value={form.influence}
              onChange={e => set('influence', +e.target.value)}/>
          </div>
          <div className="flex col gap1">
            <label>Notes</label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)}
              rows={3} placeholder="Concerns, motivations, engagement strategy…"
              style={{ resize: 'vertical' }}/>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={!form.name.trim()}>
            {initial ? 'Save Changes' : 'Add Stakeholder'}
          </button>
        </div>
      </div>
    </div>
  );
}
