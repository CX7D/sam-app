import React, { useMemo, useState } from 'react';
import { SUPPORT_MAP, REL_TYPES } from '../constants.js';

function layout(nodes, W, H) {
  if (!nodes.length) return {};
  const PAD = 80;
  const positions = {};
  nodes.forEach((n, i) => {
    const angle = (2 * Math.PI * i) / nodes.length - Math.PI / 2;
    const rx = (W / 2 - PAD);
    const ry = (H / 2 - PAD);
    positions[n.id] = {
      x: W / 2 + rx * Math.cos(angle),
      y: H / 2 + ry * Math.sin(angle)
    };
  });
  return positions;
}

const REL_COLORS = {
  reports_to: '#6080f0',
  influences: '#f0c040',
  collaborates: '#4af0b0',
  opposes: '#f04060',
  funds: '#c060f0',
  approves: '#60c0f0'
};

export default function Network({ stakeholders, relationships, onSelectStakeholder, selectedId }) {
  const W = 700, H = 480;
  const [hover, setHover] = useState(null);

  const positions = useMemo(() => layout(stakeholders, W, H), [stakeholders, W, H]);

  const relLabel = v => REL_TYPES.find(r => r.value === v)?.label || v;

  return (
    <div style={{ width: '100%', aspectRatio: '7/4.8' }}>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: '100%', display: 'block' }}>
        <defs>
          {Object.entries(REL_COLORS).map(([k, c]) => (
            <marker key={k} id={`arrow-${k}`} viewBox="0 0 10 10" refX="10" refY="5"
              markerWidth="6" markerHeight="6" orient="auto">
              <path d="M 0 0 L 10 5 L 0 10 z" fill={c}/>
            </marker>
          ))}
        </defs>

        {/* Background */}
        <rect width={W} height={H} fill="transparent"/>

        {/* Edges */}
        {relationships.map(rel => {
          const src = positions[rel.sourceId];
          const tgt = positions[rel.targetId];
          if (!src || !tgt) return null;
          const color = REL_COLORS[rel.type] || '#6b7385';
          const mx = (src.x + tgt.x) / 2;
          const my = (src.y + tgt.y) / 2;
          const isHovered = hover === rel.id;
          return (
            <g key={rel.id} onMouseEnter={() => setHover(rel.id)} onMouseLeave={() => setHover(null)}>
              <line
                x1={src.x} y1={src.y} x2={tgt.x} y2={tgt.y}
                stroke={color} strokeWidth={isHovered ? 2.5 : 1.5}
                strokeOpacity={isHovered ? 1 : .5}
                strokeDasharray={rel.type === 'opposes' ? '6 4' : undefined}
                markerEnd={`url(#arrow-${rel.type})`}
              />
              {isHovered && (
                <text x={mx} y={my - 6} textAnchor="middle" fill={color} fontSize="9"
                  fontFamily="DM Mono, monospace" fontWeight="400">
                  {relLabel(rel.type)}
                </text>
              )}
            </g>
          );
        })}

        {/* Nodes */}
        {stakeholders.map(s => {
          const p = positions[s.id];
          if (!p) return null;
          const support = SUPPORT_MAP[s.support] || SUPPORT_MAP['neutral'];
          const r = 22;
          const isSelected = s.id === selectedId;
          return (
            <g key={s.id} style={{ cursor: 'pointer' }}
               onClick={() => onSelectStakeholder(s)}>
              {isSelected && <circle cx={p.x} cy={p.y} r={r + 10} fill={support.color} opacity=".12"/>}
              <circle cx={p.x} cy={p.y} r={r}
                fill={support.color} fillOpacity={.8}
                stroke={isSelected ? '#fff' : support.color}
                strokeWidth={isSelected ? 2.5 : 1}/>
              <text x={p.x} y={p.y + 4} textAnchor="middle" fill="#0d0f12"
                fontSize="10" fontWeight="700" fontFamily="Syne, sans-serif">
                {s.name.slice(0,4).toUpperCase()}
              </text>
              <text x={p.x} y={p.y + r + 14} textAnchor="middle" fill="#e8eaf0"
                fontSize="9" fontFamily="Syne, sans-serif">
                {s.name.length > 16 ? s.name.slice(0,15)+'…' : s.name}
              </text>
            </g>
          );
        })}

        {!stakeholders.length && (
          <text x={W/2} y={H/2} textAnchor="middle" fill="#6b7385" fontSize="13" fontFamily="Syne, sans-serif">
            No stakeholders yet — add some above
          </text>
        )}
      </svg>
    </div>
  );
}
