import React, { useState } from 'react';

export default function ProjectModal({ initial, onSave, onClose }) {
  const [name, setName] = useState(initial?.name || '');
  const [desc, setDesc] = useState(initial?.description || '');

  return (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <span style={{ fontWeight: 700, fontSize: 15 }}>{initial ? 'Edit Project' : 'New Project'}</span>
          <button className="btn-icon" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div className="flex col gap1">
            <label>Project Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Digital Transformation 2026"/>
          </div>
          <div className="flex col gap1">
            <label>Description</label>
            <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} placeholder="What is this project about?"/>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={!name.trim()}
            onClick={() => onSave({ name, description: desc })}>
            {initial ? 'Save' : 'Create Project'}
          </button>
        </div>
      </div>
    </div>
  );
}
